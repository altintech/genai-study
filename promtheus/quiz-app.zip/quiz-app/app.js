// app.js
const express = require('express');
const app = express();
const port = 3000;

app.set('view engine', 'ejs');
app.use(express.static('public'));

app.get('/', (req, res) => {
    res.render('quiz', { quizData: getQuizData() });
});

app.listen(port, () => {
    console.log(`Quiz app listening at http://localhost:${port}`);
});

function getQuizData() {
    return [
        {
            question: "What is Generative AI?",
            options: {
                a: "AI that generates electrical power",
                b: "AI that creates new content",
                c: "AI used for data analysis",
                d: "AI used in robotics"
            },
            correct: "b"
        },
        {
            question: "Which technology is primarily used in Generative AI for image generation?",
            options: {
                a: "Reinforcement Learning",
                b: "Convolutional Neural Networks",
                c: "Generative Adversarial Networks",
                d: "Support Vector Machines"
            },
            correct: "c"
        },
        {
            question: "What is a key feature of Generative Adversarial Networks (GANs)?",
            options: {
                a: "Two networks competing against each other",
                b: "Use of backpropagation",
                c: "Supervised learning only",
                d: "Rule-based AI"
            },
            correct: "a"
        },
        {
            question: "Which application is a common use of Generative AI?",
            options: {
                a: "Spam filtering",
                b: "Pathfinding algorithms",
                c: "Deepfakes",
                d: "Linear regression"
            },
            correct: "c"
        },
        {
            question: "Who are considered the fathers of the Generative Adversarial Network?",
            options: {
                a: "Geoffrey Hinton and Yann LeCun",
                b: "Ian Goodfellow and Yoshua Bengio",
                c: "Andrew Ng and Peter Norvig",
                d: "Elon Musk and Jeff Bezos"
            },
            correct: "b"
        },
        {
            question: "In Generative AI, what is 'latent space'?",
            options: {
                a: "A special type of memory storage",
                b: "A high-dimensional space where data points are mapped",
                c: "A debugging tool for neural networks",
                d: "A cloud-based computing resource"
            },
            correct: "b"
        },
        {
            question: "Which of the following is a challenge in Generative AI?",
            options: {
                a: "Data compression",
                b: "Model interpretability",
                c: "Real-time processing",
                d: "All of the above"
            },
            correct: "d"
        },
        {
            question: "What is 'style transfer' in the context of Generative AI?",
            options: {
                a: "Transferring the style of one image to another",
                b: "A method of transferring data between servers",
                c: "Changing the coding style of an AI program",
                d: "A type of data encryption"
            },
            correct: "a"
        },
        {
            question: "Which of the following is an example of text-based Generative AI?",
            options: {
                a: "Google Search",
                b: "GPT-3",
                c: "AlphaGo",
                d: "Tesla Autopilot"
            },
            correct: "b"
        },
        {
            question: "What does 'fine-tuning' refer to in the context of Generative AI models?",
            options: {
                a: "Adjusting the model parameters for better performance",
                b: "Reducing the size of the model",
                c: "Increasing the speed of computation",
                d: "Improving the user interface"
            },
            correct: "a"
        }
    ];
}

